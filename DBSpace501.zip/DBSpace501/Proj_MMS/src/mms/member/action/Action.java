package mms.member.action;

public interface Action {

}
